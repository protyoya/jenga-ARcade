// Welcome to my Swift Playground
// ==============================
//           WWDC25
// - Please test on the latest iPad
// - It is designed for full screen in lanscape mode
// - Set the live view to full screen prior to starting
// - Hope you enjoy my playground!

GameManager.current.setup()
